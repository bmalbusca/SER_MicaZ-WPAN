Place folder Poj-Group4 in the examples folder of contiki.
Then, in cooja, make a new project and add receiver motes with receiver.c and sender motes with sender.c.